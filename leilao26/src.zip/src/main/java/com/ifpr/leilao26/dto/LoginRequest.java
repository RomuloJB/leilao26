package com.ifpr.leilao26.dto;

public class LoginRequest {
    private String username;
    private String senha;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
}
